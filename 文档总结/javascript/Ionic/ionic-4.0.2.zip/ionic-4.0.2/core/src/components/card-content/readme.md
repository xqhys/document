# ion-card-content

`ion-card-content` is child component of `ion-card` that adds some content padding.
It is recommended that any text content for a card should be placed in an `ion-card-content`.


<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                                       | Type            | Default     |
| -------- | --------- | ------------------------------------------------- | --------------- | ----------- |
| `mode`   | `mode`    | The mode determines which platform styles to use. | `"ios" \| "md"` | `undefined` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
