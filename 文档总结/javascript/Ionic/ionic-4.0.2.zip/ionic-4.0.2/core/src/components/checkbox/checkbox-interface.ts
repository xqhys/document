
export interface CheckboxChangeEventDetail {
  value: any;
  checked: boolean;
}
