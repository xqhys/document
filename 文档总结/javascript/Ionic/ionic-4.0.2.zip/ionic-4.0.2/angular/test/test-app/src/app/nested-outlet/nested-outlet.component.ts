import { Component } from '@angular/core';

@Component({
  selector: 'app-nested-outlet',
  templateUrl: './nested-outlet.component.html',
})
export class NestedOutletComponent {

}
