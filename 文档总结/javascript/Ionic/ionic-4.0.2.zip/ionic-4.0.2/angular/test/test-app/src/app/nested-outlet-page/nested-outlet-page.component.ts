import { Component } from '@angular/core';

@Component({
  selector: 'app-nested-outlet-page',
  templateUrl: './nested-outlet-page.component.html',
})
export class NestedOutletPageComponent {
}
