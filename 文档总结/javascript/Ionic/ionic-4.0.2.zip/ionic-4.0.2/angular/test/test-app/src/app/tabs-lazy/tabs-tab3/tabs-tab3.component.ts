import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabs-tab3',
  templateUrl: './tabs-tab3.component.html',
})
export class TabsTab3Component {}
