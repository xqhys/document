# Ionic Angular Test App

```
npm install
npm run sync:build
npm start
```
