import { Component } from '@angular/core';

@Component({
  selector: 'app-nested-outlet-page2',
  templateUrl: './nested-outlet-page2.component.html',
})
export class NestedOutletPage2Component {
}
