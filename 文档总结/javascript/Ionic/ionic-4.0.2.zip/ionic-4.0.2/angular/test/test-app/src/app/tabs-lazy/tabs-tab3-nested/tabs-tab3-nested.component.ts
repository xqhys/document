import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs-tab3-nested',
  templateUrl: './tabs-tab3-nested.component.html',
})
export class TabsTab3NestedComponent {}
