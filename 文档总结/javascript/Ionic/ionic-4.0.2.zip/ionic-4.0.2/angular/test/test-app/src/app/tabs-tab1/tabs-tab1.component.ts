import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs-tab1',
  templateUrl: './tabs-tab1.component.html',
})
export class TabsTab1Component { }
