import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs-tab1-nested',
  templateUrl: './tabs-tab1-nested.component.html',
})
export class TabsTab1NestedComponent { }
