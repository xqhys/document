import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs-tab2',
  templateUrl: './tabs-tab2.component.html',
})
export class TabsTab2Component { }
