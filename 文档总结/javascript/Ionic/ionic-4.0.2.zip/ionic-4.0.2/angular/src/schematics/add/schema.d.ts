export interface Schema {
  project?: string;
}
