
export interface VirtualContext {
  $implicit: any;
  index: number;
}
