---
name: Support Question
about: Question on how to use this project
title: ''
labels: 'ionitron: support'
assignees: ''
---

# Support Question

Please do not submit support requests or "How to" questions here. Instead, please use one of these channels: https://forum.ionicframework.com/ or http://ionicworldwide.herokuapp.com/
