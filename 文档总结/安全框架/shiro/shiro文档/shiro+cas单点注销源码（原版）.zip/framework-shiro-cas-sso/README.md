﻿# [Shiro & CAS 实现单点登录](http://howiefh.github.io/2015/05/19/shiro-cas-single-sign-on)

客户端基于开涛shiro教程[第十五章](https://github.com/zhangkaitao/shiro-example/tree/master/shiro-example-chapter15-client)

cas服务端基于[Jasig CAS](https://github.com/Jasig/cas/releases)
