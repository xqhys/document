package com.hxy.app.service;

/**
 * 类的功能描述.
 *
 * @Auther hxy
 * @Date 2017/10/20
 */

public interface ApiNoticeService {
    /**
     * 我的通知条数
     * @return
     */
    int myNoticeCount(String userId);

}
